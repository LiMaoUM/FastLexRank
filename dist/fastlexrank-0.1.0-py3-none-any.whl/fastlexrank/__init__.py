# __init__.py

# Version of the package
__version__ = "0.1.0"

from FastLexRank.FastLexRank import FastLexRankSummarizer
